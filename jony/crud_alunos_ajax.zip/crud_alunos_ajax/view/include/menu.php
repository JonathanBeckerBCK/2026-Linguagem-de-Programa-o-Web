<?php
require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/LoginController.php");

$loginCont = new LoginController();
$nomeUsuario = $loginCont->getNomeUsuarioLogado();

?>

<nav class="navbar navbar-expand-md bg-warning px-3">
    
    <a class="navbar-brand" href="<?= BASE_URL ?>/index.php">Sistema acadêmico</a>

    <button class="navbar-toggler" type="button"
        data-bs-toggle="collapse" data-bs-target="#navSite">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navSite">
    
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/index.php">Home</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#"
                    id="navDropDown" data-bs-toggle="dropdown">Cadastros</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?= BASE_URL ?>/view/alunos/listar.php">
                        Alunos</a>
                    <a class="dropdown-item" href="<?= BASE_URL ?>/view/turmas/listar.php">
                        Turmas</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#"
                    id="navDropDown2" data-bs-toggle="dropdown"><?= $nomeUsuario ?></a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?= BASE_URL ?>/view/perfil/perfil.php">
                        Perfil</a>                    
                    <a class="dropdown-item" href="<?= BASE_URL ?>/view/login/sair.php">
                        Sair</a>                    
                </div>
            </li>
        </ul>
        
    </div>
</nav>